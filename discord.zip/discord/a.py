import os
import requests
from dotenv import load_dotenv

# โหลดข้อมูลจาก .env
load_dotenv()
WEBHOOK_URL = os.getenv("DISCORD_WEBHOOK_URL")

# แมปตัวเลือกกับวันและชื่อไฟล์
days = {
    'a': ('จันทร์', 'a.png'),
    'b': ('อังคาร', 'b.png'),
    'c': ('พุธ', 'c.png'),
    'd': ('พฤหัสบดี', 'd.png'),
    'e': ('ศุกร์', 'e.png'),
    'f': ('เสาร์', 'f.png'),
    'g': ('อาทิตย์', 'g.png'),
}

# แสดงเมนูให้เลือก
print("a = จันทร์")
print("b = อังคาร")
print("c = พุธ")
print("d = พฤหัสบดี")
print("e = ศุกร์")
print("f = เสาร์")
print("g = อาทิตย์")
choice = input("เลือกอะไร\n__ ").lower()

# ตรวจสอบตัวเลือก
if choice in days:
    day_name, filename = days[choice]

    # หาตำแหน่งไฟล์ภาพจาก path ของสคริปต์นี้
    script_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(script_dir, filename)

    if os.path.isfile(filepath):
        print(f'คุณเลือก {day_name}')
        print(f'ส่งภาพ {filename} ไปยัง Discord...')

        with open(filepath, 'rb') as f:
            files = {'file': (filename, f)}
            data = {'content': f'@everyone สวัสดีวัน{day_name}'}
            response = requests.post(WEBHOOK_URL, data=data, files=files)
    else:
        print(f'ไม่พบไฟล์: {filepath} -> ส่งข้อความ "@everyone บอทมีปัญหา"')
        data = {'content': '@everyone บอทมีปัญหา'}
        response = requests.post(WEBHOOK_URL, data=data)

    # ตรวจสอบผลลัพธ์
    if response.status_code in [200, 204]:
        print("✅ ส่งข้อความไปยัง Discord สำเร็จ")
    else:
        print(f"❌ ส่งไม่สำเร็จ: {response.status_code} - {response.text}")
else:
    print("ตัวเลือกไม่ถูกต้อง")
